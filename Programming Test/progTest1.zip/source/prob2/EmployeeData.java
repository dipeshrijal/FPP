package prob2;

public interface EmployeeData {

}
